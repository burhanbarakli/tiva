﻿/*
 * Created by SharpDevelop.
 * User: bb
 * Date: 5.12.2022
 * Time: 13:51
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace bb
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		string gelenveri=string.Empty;
		public MainForm()
		{
			InitializeComponent();
		}
		
		
		//port ac kismi
		void Button1Click(object sender, EventArgs e)
		{
			if (!serialPort1.IsOpen){
				serialPort1.PortName=textPort.Text;
				serialPort1.BaudRate=9600;
				serialPort1.Open();
			}
		}
		void Button2Click(object sender, EventArgs e)
		{
			serialPort1.Write(textBox3.Text);
		}
		void SerialPort1DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
		{
			string c=serialPort1.ReadExisting();
			gelenveri=gelenveri+c;
			this.Invoke(new EventHandler(displaytext));
			
		}
		
		void displaytext(object sender, EventArgs e){
			textBox4.Text=gelenveri;
		}
		
		void BtnportkapatClick(object sender, EventArgs e)
		{
			// doldur
		}
		void Label4Click(object sender, EventArgs e)
		{
	
		}
	}
}
