﻿/*
 * Created by SharpDevelop.
 * User: bb
 * Date: 5.12.2022
 * Time: 13:51
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace bb
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.TextBox textPort;
		private System.Windows.Forms.TextBox textBox3;
		private System.IO.Ports.SerialPort serialPort1;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.TextBox textBox4;
		private System.Windows.Forms.Button btnportkapat;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Button btnsaat;
		private System.Windows.Forms.Label label4;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.button1 = new System.Windows.Forms.Button();
			this.textPort = new System.Windows.Forms.TextBox();
			this.textBox3 = new System.Windows.Forms.TextBox();
			this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
			this.button2 = new System.Windows.Forms.Button();
			this.textBox4 = new System.Windows.Forms.TextBox();
			this.btnportkapat = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.btnsaat = new System.Windows.Forms.Button();
			this.label4 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(241, 15);
			this.button1.Margin = new System.Windows.Forms.Padding(6);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(150, 44);
			this.button1.TabIndex = 0;
			this.button1.Text = "port ac";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.Button1Click);
			// 
			// textPort
			// 
			this.textPort.Location = new System.Drawing.Point(119, 22);
			this.textPort.Name = "textPort";
			this.textPort.Size = new System.Drawing.Size(100, 31);
			this.textPort.TabIndex = 1;
			this.textPort.Text = "COM5";
			// 
			// textBox3
			// 
			this.textBox3.Location = new System.Drawing.Point(119, 142);
			this.textBox3.Name = "textBox3";
			this.textBox3.Size = new System.Drawing.Size(193, 31);
			this.textBox3.TabIndex = 2;
			// 
			// serialPort1
			// 
			this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.SerialPort1DataReceived);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(336, 135);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(162, 44);
			this.button2.TabIndex = 3;
			this.button2.Text = "metin gonder";
			this.button2.UseVisualStyleBackColor = true;
			this.button2.Click += new System.EventHandler(this.Button2Click);
			// 
			// textBox4
			// 
			this.textBox4.Location = new System.Drawing.Point(259, 360);
			this.textBox4.Name = "textBox4";
			this.textBox4.Size = new System.Drawing.Size(336, 31);
			this.textBox4.TabIndex = 4;
			// 
			// btnportkapat
			// 
			this.btnportkapat.Location = new System.Drawing.Point(415, 15);
			this.btnportkapat.Margin = new System.Windows.Forms.Padding(6);
			this.btnportkapat.Name = "btnportkapat";
			this.btnportkapat.Size = new System.Drawing.Size(150, 44);
			this.btnportkapat.TabIndex = 5;
			this.btnportkapat.Text = "port kapat";
			this.btnportkapat.UseVisualStyleBackColor = true;
			this.btnportkapat.Click += new System.EventHandler(this.BtnportkapatClick);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(13, 25);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(100, 28);
			this.label1.TabIndex = 6;
			this.label1.Text = "port no";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(51, 360);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(190, 28);
			this.label2.TabIndex = 6;
			this.label2.Text = "MC den gelenler";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(13, 142);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(85, 28);
			this.label3.TabIndex = 6;
			this.label3.Text = "metin";
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(119, 219);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(193, 31);
			this.textBox1.TabIndex = 7;
			this.textBox1.Text = "12:34:56";
			// 
			// btnsaat
			// 
			this.btnsaat.Location = new System.Drawing.Point(336, 212);
			this.btnsaat.Name = "btnsaat";
			this.btnsaat.Size = new System.Drawing.Size(162, 45);
			this.btnsaat.TabIndex = 8;
			this.btnsaat.Text = "Saat Gonder";
			this.btnsaat.UseVisualStyleBackColor = true;
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(12, 222);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(85, 28);
			this.label4.TabIndex = 6;
			this.label4.Text = "saat";
			this.label4.Click += new System.EventHandler(this.Label4Click);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(749, 537);
			this.Controls.Add(this.btnsaat);
			this.Controls.Add(this.textBox1);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.btnportkapat);
			this.Controls.Add(this.textBox4);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.textBox3);
			this.Controls.Add(this.textPort);
			this.Controls.Add(this.button1);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.Margin = new System.Windows.Forms.Padding(6);
			this.Name = "MainForm";
			this.Text = "bb";
			this.ResumeLayout(false);
			this.PerformLayout();

		}
	}
}
